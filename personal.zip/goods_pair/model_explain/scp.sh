scp work@bj-pfredis05:/home/work/ml/model_common/new_model_c_2 .

