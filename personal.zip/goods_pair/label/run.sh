source /etc/bashrc


root_path=$1
#day=`date +"%Y-%m-%d" -d "-1 days"`
day=$2

python luna.py $root_path
python Main.py -root_path $root_path -day $day




