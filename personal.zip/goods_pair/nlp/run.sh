source /etc/bashrc


root_path=$1

day=$2

python getCata.py > cata_dict

python Main.py -root_path $root_path -day $day



