rm goods_pv
hadoop fs -getmerge /user/chongweishen/personal_4_pair/item_sim/goods_pv goods_pv
/usr/local/bin/python filt.py > pv_dict



