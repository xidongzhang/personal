source /etc/bashrc


root_path=$1

#for((i=1;i<=90;i++));
#do
    #day=`date +"%Y-%m-%d" -d "-1 days"`
    day=$2
    sh act.sh $root_path
    python Main.py -root_path $root_path -day $day
#done;




