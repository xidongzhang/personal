#coding=utf8
import sys
import os
import time

if __name__ == '__main__':
    for line in sys.stdin:
        line = line.strip()
        print line
        #if(line == ""):
        #    continue
        #order_id, ctime, tid, uid, price, color, size = line.split("\t")
         
        
        

        
         













