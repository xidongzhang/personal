#!/usr/bin/python

import sys

i = 2

for line in sys.stdin :
    (fea, count) = line.strip().split(" ")
    print "%s\t%s\t%d\t4" % (fea, count, i)
    i += 1
